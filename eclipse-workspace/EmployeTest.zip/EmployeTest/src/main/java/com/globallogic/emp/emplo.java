package com.globallogic.emp;

public class emplo {

}
