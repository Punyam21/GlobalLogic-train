package com.globallogic.query;

public class Myquery {

}
